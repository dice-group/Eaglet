java -Xmx8g -classpath bin:benchmark/systems/illinois/Code/lib/*:benchmark/libs/illinois/Wikifier.jar it.acubelab.batframework.systemPlugins.IllinoisAnnotator_Server
