
function userValidation() {
	// get the form data using another method
	loginName = $("input#user").val();

	$.ajax({
		url : "service/login",// servlet URL that gets
		type : "POST",// request type, can be GET
		data : {
			username : loginName,// data to be sent
		},
		dataType : "string"// type of data returned
		success : function(data) {
				console.log("SUCCESS: ", data);
				display(data);
			},
			error : function(e) {
				console.log("ERROR: ",e);
				display(e);
			},
			done : function(e) {
				console.log("DONE");
				window.location.href ="home_page.html"
			}
	});
};
function display(data) {
		var msg = "<p>"
			data + "</p>";
		$('#feedback').html(msg);
	}

	function userregistration() {
		// get the form data using another method
		loginName = $("input#user").val();
};
